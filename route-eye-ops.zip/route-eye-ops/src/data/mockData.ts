// Mock data for the logistics monitoring dashboard

export interface KPIData {
  label: string;
  value: number | string;
  unit?: string;
  meta?: number | null;
  metaLabel?: string;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  status?: "success" | "warning" | "danger" | "neutral";
}

export interface AlertData {
  id: string;
  rota: string;
  filial: string;
  tipo: "nao_planejada" | "sem_tempo" | "overtime" | "desalinhada" | "entrega_critica" | "match_critico";
  transportador: string;
  motorista: string;
  placa: string;
  data: string;
  descricao: string;
}

export interface RouteData {
  rota: string;
  filial: string;
  transportador: string;
  tipoVeiculo: string;
  motorista: string;
  placa: string;
  status: "concluida" | "em_andamento" | "atrasada" | "cancelada";
  pedidos: number;
  volumes: number;
  entregas: number;
  insucessos: number;
  kmRealizado: number;
  pesoRealizado: number;
  tempoMedio: number;
  ocupacaoComposta: number;
  aderenciaVolumes: number;
  custoMedioCarga: number;
  scoreOperacional: number;
}

export const alertTypeLabels: Record<AlertData["tipo"], string> = {
  nao_planejada: "Não Planejada",
  sem_tempo: "Sem Tempo",
  overtime: "Overtime",
  desalinhada: "Desalinhada",
  entrega_critica: "Entrega Crítica",
  match_critico: "Match Crítico",
};

export const alertTypeColors: Record<AlertData["tipo"], string> = {
  nao_planejada: "bg-warning/15 text-warning",
  sem_tempo: "bg-muted text-muted-foreground",
  overtime: "bg-destructive/15 text-destructive",
  desalinhada: "bg-accent/15 text-accent",
  entrega_critica: "bg-destructive/15 text-destructive",
  match_critico: "bg-warning/15 text-warning",
};

export const statusLabels: Record<RouteData["status"], string> = {
  concluida: "Concluída",
  em_andamento: "Em Andamento",
  atrasada: "Atrasada",
  cancelada: "Cancelada",
};

export const statusColors: Record<RouteData["status"], string> = {
  concluida: "bg-success/15 text-success",
  em_andamento: "bg-primary/15 text-primary",
  atrasada: "bg-warning/15 text-warning",
  cancelada: "bg-destructive/15 text-destructive",
};

export const resumoKPIs: KPIData[] = [
  { label: "Rotas", value: 1247, unit: "rotas", trend: "up", trendValue: "+3.2%", status: "success" },
  { label: "Pedidos", value: 18432, unit: "ped.", trend: "up", trendValue: "+5.1%", status: "success" },
  { label: "Volumes", value: 42871, unit: "vol.", trend: "down", trendValue: "-1.4%", status: "warning" },
  { label: "Entregas Efetivas", value: 94.7, unit: "%", meta: 95, metaLabel: "Meta", trend: "down", trendValue: "-0.3pp", status: "warning" },
  { label: "SPR Pedidos", value: 14.8, unit: "ped/rota", meta: 15, metaLabel: "Meta", trend: "neutral", trendValue: "=", status: "neutral" },
  { label: "Score Operacional", value: 87.3, unit: "pts", trend: "up", trendValue: "+2.1", status: "success" },
];

export const custosKPIs: KPIData[] = [
  { label: "Valor Pagamento Carga", value: "R$ 2.847.320", unit: "", trend: "up", trendValue: "+4.8%", status: "warning" },
  { label: "Custo Médio/Carga", value: "R$ 2.283", unit: "/carga", trend: "down", trendValue: "-1.2%", status: "success" },
  { label: "Custo Médio/Volume", value: "R$ 66,40", unit: "/vol", trend: "down", trendValue: "-2.3%", status: "success" },
  { label: "Custo Médio/Pedido", value: "R$ 154,50", unit: "/ped", trend: "up", trendValue: "+0.8%", status: "warning" },
];

export const frotaKPIs: KPIData[] = [
  { label: "Veículos Ativos", value: 312, unit: "veíc.", trend: "neutral", trendValue: "=", status: "neutral" },
  { label: "Motoristas Ativos", value: 298, unit: "mot.", trend: "down", trendValue: "-2", status: "warning" },
  { label: "Ocupação Composta", value: 78.4, unit: "%", meta: 82, metaLabel: "Meta", trend: "up", trendValue: "+1.2pp", status: "warning" },
  { label: "Ocupação Pedidos", value: 84.2, unit: "%", trend: "up", trendValue: "+0.8pp", status: "success" },
  { label: "Ocupação Volumes", value: 72.6, unit: "%", trend: "down", trendValue: "-0.5pp", status: "warning" },
];

export const tempoKPIs: KPIData[] = [
  { label: "Tempo Médio Realizado", value: "4h 23min", unit: "", trend: "down", trendValue: "-12min", status: "success" },
  { label: "ORH", value: 8.7, unit: "ent/h", meta: 9.0, metaLabel: "Meta", trend: "up", trendValue: "+0.3", status: "warning" },
  { label: "Rotas Concluídas", value: 92.1, unit: "%", meta: 95, metaLabel: "Meta", trend: "down", trendValue: "-0.8pp", status: "warning" },
  { label: "Ociosidade", value: 12.4, unit: "%", trend: "down", trendValue: "-1.1pp", status: "success" },
  { label: "Overtime", value: 47, unit: "rotas", trend: "up", trendValue: "+8", status: "danger" },
];

export const aderenciaKPIs: KPIData[] = [
  { label: "Aderência Pedidos", value: 91.2, unit: "%", trend: "up", trendValue: "+0.4pp", status: "success" },
  { label: "Aderência Volumes", value: 88.7, unit: "%", meta: 90, metaLabel: "Meta", trend: "down", trendValue: "-0.8pp", status: "warning" },
  { label: "Aderência Peso", value: 93.1, unit: "%", trend: "up", trendValue: "+1.2pp", status: "success" },
  { label: "Aderência KM", value: 86.4, unit: "%", trend: "neutral", trendValue: "=", status: "neutral" },
  { label: "Aderência Tempo", value: 84.9, unit: "%", trend: "down", trendValue: "-1.5pp", status: "warning" },
  { label: "Match Mesmo Dia", value: 76.3, unit: "%", trend: "up", trendValue: "+2.1pp", status: "success" },
];

export const weeklyTrend = [
  { semana: "S01", rotas: 310, pedidos: 4520, entregasEfetivas: 94.2, sprPedidos: 14.6 },
  { semana: "S02", rotas: 325, pedidos: 4680, entregasEfetivas: 95.1, sprPedidos: 14.4 },
  { semana: "S03", rotas: 298, pedidos: 4380, entregasEfetivas: 93.8, sprPedidos: 14.7 },
  { semana: "S04", rotas: 314, pedidos: 4852, entregasEfetivas: 94.7, sprPedidos: 15.4 },
];

export const filialPerformance = [
  { filial: "SP Capital", rotas: 342, pedidos: 5120, entregasEfetivas: 96.2, score: 91.4 },
  { filial: "RJ Metro", rotas: 218, pedidos: 3240, entregasEfetivas: 93.8, score: 86.7 },
  { filial: "BH", rotas: 156, pedidos: 2380, entregasEfetivas: 95.1, score: 89.2 },
  { filial: "Curitiba", rotas: 134, pedidos: 1920, entregasEfetivas: 94.4, score: 88.1 },
  { filial: "POA", rotas: 112, pedidos: 1680, entregasEfetivas: 92.7, score: 84.3 },
  { filial: "Campinas", rotas: 98, pedidos: 1450, entregasEfetivas: 97.1, score: 92.8 },
  { filial: "Salvador", rotas: 87, pedidos: 1312, entregasEfetivas: 91.4, score: 82.5 },
  { filial: "Recife", rotas: 100, pedidos: 1330, entregasEfetivas: 93.2, score: 85.9 },
];

export const transportadorData = [
  { transportador: "Rapido Translog", rotas: 287, share: 23.0, custoMedioCarga: 2150, entregasEfetivas: 96.1, score: 91.2 },
  { transportador: "Expresso Sul", rotas: 214, share: 17.2, custoMedioCarga: 2340, entregasEfetivas: 94.3, score: 87.8 },
  { transportador: "Carga Segura", rotas: 198, share: 15.9, custoMedioCarga: 2180, entregasEfetivas: 95.7, score: 90.1 },
  { transportador: "Norte Log", rotas: 167, share: 13.4, custoMedioCarga: 2520, entregasEfetivas: 92.4, score: 84.6 },
  { transportador: "TransBrasil", rotas: 145, share: 11.6, custoMedioCarga: 2410, entregasEfetivas: 93.8, score: 86.3 },
  { transportador: "Via Rápida", rotas: 126, share: 10.1, custoMedioCarga: 2290, entregasEfetivas: 94.9, score: 88.5 },
  { transportador: "Outros", rotas: 110, share: 8.8, custoMedioCarga: 2680, entregasEfetivas: 91.2, score: 82.1 },
];

export const alerts: AlertData[] = [
  { id: "A001", rota: "RT-4521", filial: "SP Capital", tipo: "overtime", transportador: "Expresso Sul", motorista: "Carlos Mendes", placa: "ABC-1234", data: "2026-03-19", descricao: "Rota excedeu tempo máximo em 2h14min" },
  { id: "A002", rota: "RT-3287", filial: "RJ Metro", tipo: "entrega_critica", transportador: "Norte Log", motorista: "Roberto Alves", placa: "DEF-5678", data: "2026-03-19", descricao: "3 tentativas de entrega sem sucesso" },
  { id: "A003", rota: "RT-1892", filial: "BH", tipo: "nao_planejada", transportador: "Carga Segura", motorista: "Ana Paula Silva", placa: "GHI-9012", data: "2026-03-20", descricao: "Rota criada fora do planejamento" },
  { id: "A004", rota: "RT-5643", filial: "Curitiba", tipo: "sem_tempo", transportador: "Rapido Translog", motorista: "Marcos Lima", placa: "JKL-3456", data: "2026-03-20", descricao: "Sem registro de tempo de rota" },
  { id: "A005", rota: "RT-2198", filial: "POA", tipo: "desalinhada", transportador: "Via Rápida", motorista: "Fernanda Costa", placa: "MNO-7890", data: "2026-03-20", descricao: "Sequência de entrega divergente do planejado" },
  { id: "A006", rota: "RT-7821", filial: "Salvador", tipo: "match_critico", transportador: "TransBrasil", motorista: "João Pereira", placa: "PQR-1234", data: "2026-03-19", descricao: "Match mesmo dia abaixo de 50%" },
];

export const routeDetails: RouteData[] = [
  { rota: "RT-4521", filial: "SP Capital", transportador: "Expresso Sul", tipoVeiculo: "VUC", motorista: "Carlos Mendes", placa: "ABC-1234", status: "atrasada", pedidos: 18, volumes: 42, entregas: 15, insucessos: 2, kmRealizado: 87.3, pesoRealizado: 1240, tempoMedio: 385, ocupacaoComposta: 82.1, aderenciaVolumes: 88.4, custoMedioCarga: 2340, scoreOperacional: 72.4 },
  { rota: "RT-3287", filial: "RJ Metro", transportador: "Norte Log", tipoVeiculo: "Toco", motorista: "Roberto Alves", placa: "DEF-5678", status: "em_andamento", pedidos: 24, volumes: 58, entregas: 18, insucessos: 4, kmRealizado: 112.7, pesoRealizado: 2180, tempoMedio: 320, ocupacaoComposta: 76.3, aderenciaVolumes: 82.1, custoMedioCarga: 2520, scoreOperacional: 68.9 },
  { rota: "RT-1892", filial: "BH", transportador: "Carga Segura", tipoVeiculo: "3/4", motorista: "Ana Paula Silva", placa: "GHI-9012", status: "concluida", pedidos: 12, volumes: 28, entregas: 12, insucessos: 0, kmRealizado: 54.2, pesoRealizado: 860, tempoMedio: 245, ocupacaoComposta: 91.2, aderenciaVolumes: 96.3, custoMedioCarga: 1850, scoreOperacional: 94.7 },
  { rota: "RT-5643", filial: "Curitiba", transportador: "Rapido Translog", tipoVeiculo: "VUC", motorista: "Marcos Lima", placa: "JKL-3456", status: "concluida", pedidos: 16, volumes: 38, entregas: 15, insucessos: 1, kmRealizado: 72.8, pesoRealizado: 1120, tempoMedio: 298, ocupacaoComposta: 84.7, aderenciaVolumes: 91.8, custoMedioCarga: 2150, scoreOperacional: 88.3 },
  { rota: "RT-2198", filial: "POA", transportador: "Via Rápida", tipoVeiculo: "Toco", motorista: "Fernanda Costa", placa: "MNO-7890", status: "em_andamento", pedidos: 22, volumes: 51, entregas: 14, insucessos: 1, kmRealizado: 95.1, pesoRealizado: 1890, tempoMedio: 275, ocupacaoComposta: 79.5, aderenciaVolumes: 85.7, custoMedioCarga: 2290, scoreOperacional: 81.2 },
  { rota: "RT-7821", filial: "Salvador", transportador: "TransBrasil", tipoVeiculo: "3/4", motorista: "João Pereira", placa: "PQR-1234", status: "cancelada", pedidos: 8, volumes: 19, entregas: 0, insucessos: 0, kmRealizado: 0, pesoRealizado: 0, tempoMedio: 0, ocupacaoComposta: 0, aderenciaVolumes: 0, custoMedioCarga: 2410, scoreOperacional: 0 },
];

export const planejadoVsRealizado = [
  { filial: "SP Capital", planejadoPedidos: 5200, realizadoPedidos: 5120, planejadoVolumes: 12100, realizadoVolumes: 11840 },
  { filial: "RJ Metro", planejadoPedidos: 3400, realizadoPedidos: 3240, planejadoVolumes: 7800, realizadoVolumes: 7420 },
  { filial: "BH", planejadoPedidos: 2500, realizadoPedidos: 2380, planejadoVolumes: 5600, realizadoVolumes: 5480 },
  { filial: "Curitiba", planejadoPedidos: 2000, realizadoPedidos: 1920, planejadoVolumes: 4500, realizadoVolumes: 4380 },
  { filial: "POA", planejadoPedidos: 1800, realizadoPedidos: 1680, planejadoVolumes: 4100, realizadoVolumes: 3870 },
  { filial: "Campinas", planejadoPedidos: 1500, realizadoPedidos: 1450, planejadoVolumes: 3400, realizadoVolumes: 3350 },
];

export const motoristaJornada = [
  { motorista: "Carlos Mendes", rotasHoje: 3, horasJornada: 10.5, overtime: true, entregas: 42, insucessos: 3, score: 78.4 },
  { motorista: "Roberto Alves", rotasHoje: 2, horasJornada: 8.2, overtime: false, entregas: 36, insucessos: 4, score: 72.1 },
  { motorista: "Ana Paula Silva", rotasHoje: 2, horasJornada: 7.4, overtime: false, entregas: 28, insucessos: 0, score: 96.2 },
  { motorista: "Marcos Lima", rotasHoje: 2, horasJornada: 9.1, overtime: true, entregas: 31, insucessos: 1, score: 89.7 },
  { motorista: "Fernanda Costa", rotasHoje: 2, horasJornada: 7.8, overtime: false, entregas: 33, insucessos: 1, score: 85.3 },
  { motorista: "João Pereira", rotasHoje: 1, horasJornada: 3.2, overtime: false, entregas: 0, insucessos: 0, score: 0 },
];
