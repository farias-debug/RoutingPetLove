import SectionCard from "@/components/dashboard/SectionCard";
import StatusChip from "@/components/dashboard/StatusChip";
import { motoristaJornada } from "@/data/mockData";

export default function MotoristasJornada() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Motoristas Ativos", value: "298", unit: "mot." },
          { label: "Média Rotas/Dia", value: "2.1", unit: "rotas" },
          { label: "Jornada Média", value: "7h 42min", unit: "" },
          { label: "Overtime", value: "47", unit: "ocorrências" },
        ].map((kpi, i) => (
          <div key={kpi.label} className="rounded-xl bg-card p-4 card-shadow-soft opacity-0 animate-fade-in-up" style={{ animationDelay: `${i * 60}ms` }}>
            <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground mb-2">{kpi.label}</p>
            <p className="text-2xl font-extrabold tracking-tight text-foreground leading-none">
              {kpi.value}
              {kpi.unit && <span className="text-sm font-semibold text-muted-foreground ml-1">{kpi.unit}</span>}
            </p>
          </div>
        ))}
      </div>

      <SectionCard title="Jornada dos Motoristas" subtitle="Visão operacional do dia" delay={300}>
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-border">
                {["Motorista", "Rotas Hoje", "Horas Jornada", "Overtime", "Entregas", "Insucessos", "Score"].map(h => (
                  <th key={h} className="text-left py-2 px-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {motoristaJornada.map(m => (
                <tr key={m.motorista} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <td className="py-2.5 px-3 font-bold">{m.motorista}</td>
                  <td className="py-2.5 px-3 tabular-nums">{m.rotasHoje}</td>
                  <td className="py-2.5 px-3 tabular-nums">{m.horasJornada.toFixed(1)}h</td>
                  <td className="py-2.5 px-3">
                    <StatusChip
                      label={m.overtime ? "Sim" : "Não"}
                      colorClass={m.overtime ? "bg-destructive/15 text-destructive" : "bg-success/15 text-success"}
                    />
                  </td>
                  <td className="py-2.5 px-3 tabular-nums">{m.entregas}</td>
                  <td className="py-2.5 px-3 tabular-nums">{m.insucessos}</td>
                  <td className="py-2.5 px-3 font-bold tabular-nums">{m.score > 0 ? m.score : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  );
}
