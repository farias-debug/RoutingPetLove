import KPICard from "@/components/dashboard/KPICard";
import SectionCard from "@/components/dashboard/SectionCard";
import { custosKPIs, transportadorData } from "@/data/mockData";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";

export default function CustosEficiencia() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {custosKPIs.map((kpi, i) => (
          <KPICard key={kpi.label} data={kpi} delay={i * 60} />
        ))}
      </div>

      <SectionCard title="Custo Médio por Carga — Transportador" subtitle="R$/carga" delay={300}>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={transportadorData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 13% 91%)" />
              <XAxis dataKey="transportador" tick={{ fontSize: 10, fontWeight: 600, fill: "#667085" }} />
              <YAxis tick={{ fontSize: 11, fontWeight: 600, fill: "#667085" }} />
              <Tooltip contentStyle={{ borderRadius: 10, border: "none", boxShadow: "0 8px 24px rgba(0,0,0,0.08)", fontSize: 12, fontWeight: 600 }} />
              <Bar dataKey="custoMedioCarga" fill="#522B8F" name="R$/Carga" radius={[4, 4, 0, 0]} barSize={32} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </SectionCard>

      <SectionCard title="Detalhamento por Transportador" delay={360}>
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-border">
                {["Transportador", "Rotas", "Share %", "R$/Carga", "Entregas %", "Score"].map(h => (
                  <th key={h} className="text-left py-2 px-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {transportadorData.map(t => (
                <tr key={t.transportador} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <td className="py-2.5 px-3 font-bold">{t.transportador}</td>
                  <td className="py-2.5 px-3 tabular-nums">{t.rotas}</td>
                  <td className="py-2.5 px-3 tabular-nums">{t.share.toFixed(1)}%</td>
                  <td className="py-2.5 px-3 tabular-nums">R$ {t.custoMedioCarga.toLocaleString("pt-BR")}</td>
                  <td className="py-2.5 px-3 tabular-nums">{t.entregasEfetivas}%</td>
                  <td className="py-2.5 px-3 tabular-nums font-bold">{t.score}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  );
}
