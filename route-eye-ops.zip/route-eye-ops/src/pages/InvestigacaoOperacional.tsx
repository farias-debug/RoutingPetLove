import SectionCard from "@/components/dashboard/SectionCard";
import StatusChip from "@/components/dashboard/StatusChip";
import { alerts, alertTypeLabels, alertTypeColors, routeDetails, statusLabels, statusColors } from "@/data/mockData";

export default function InvestigacaoOperacional() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
        {[
          { label: "Não Planejadas", value: 12, color: "text-warning" },
          { label: "Sem Tempo", value: 8, color: "text-muted-foreground" },
          { label: "Overtime", value: 47, color: "text-destructive" },
          { label: "Desalinhadas", value: 23, color: "text-accent" },
          { label: "Entrega Crítica", value: 15, color: "text-destructive" },
          { label: "Match Crítico", value: 9, color: "text-warning" },
        ].map((a, i) => (
          <div key={a.label} className="rounded-xl bg-card p-4 card-shadow-soft opacity-0 animate-fade-in-up" style={{ animationDelay: `${i * 60}ms` }}>
            <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground mb-2">{a.label}</p>
            <p className={`text-2xl font-extrabold tracking-tight leading-none ${a.color}`}>{a.value}</p>
            <p className="text-[10px] font-semibold text-muted-foreground mt-1">ocorrências</p>
          </div>
        ))}
      </div>

      <SectionCard title="Alertas Ativos" subtitle="Todos os alertas operacionais do período" delay={400}>
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-border">
                {["Rota", "Filial", "Tipo", "Transportador", "Motorista", "Placa", "Data", "Descrição"].map(h => (
                  <th key={h} className="text-left py-2 px-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {alerts.map(a => (
                <tr key={a.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <td className="py-2.5 px-3 font-bold">{a.rota}</td>
                  <td className="py-2.5 px-3">{a.filial}</td>
                  <td className="py-2.5 px-3"><StatusChip label={alertTypeLabels[a.tipo]} colorClass={alertTypeColors[a.tipo]} /></td>
                  <td className="py-2.5 px-3">{a.transportador}</td>
                  <td className="py-2.5 px-3">{a.motorista}</td>
                  <td className="py-2.5 px-3 font-mono text-xs">{a.placa}</td>
                  <td className="py-2.5 px-3 tabular-nums">{a.data}</td>
                  <td className="py-2.5 px-3 text-muted-foreground max-w-xs truncate">{a.descricao}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>

      <SectionCard title="Detalhe das Rotas" subtitle="Todas as rotas com indicadores operacionais" delay={460}>
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-border">
                {["Rota", "Filial", "Status", "Ped.", "Vol.", "Entregas", "Insuc.", "KM", "Peso kg", "Ocup. %", "Score"].map(h => (
                  <th key={h} className="text-left py-2 px-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {routeDetails.map(r => (
                <tr key={r.rota} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <td className="py-2.5 px-3 font-bold">{r.rota}</td>
                  <td className="py-2.5 px-3">{r.filial}</td>
                  <td className="py-2.5 px-3"><StatusChip label={statusLabels[r.status]} colorClass={statusColors[r.status]} /></td>
                  <td className="py-2.5 px-3 tabular-nums">{r.pedidos}</td>
                  <td className="py-2.5 px-3 tabular-nums">{r.volumes}</td>
                  <td className="py-2.5 px-3 tabular-nums">{r.entregas}</td>
                  <td className="py-2.5 px-3 tabular-nums">{r.insucessos}</td>
                  <td className="py-2.5 px-3 tabular-nums">{r.kmRealizado}</td>
                  <td className="py-2.5 px-3 tabular-nums">{r.pesoRealizado.toLocaleString("pt-BR")}</td>
                  <td className="py-2.5 px-3 tabular-nums">{r.ocupacaoComposta > 0 ? `${r.ocupacaoComposta}%` : "—"}</td>
                  <td className="py-2.5 px-3 font-bold tabular-nums">{r.scoreOperacional > 0 ? r.scoreOperacional : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  );
}
