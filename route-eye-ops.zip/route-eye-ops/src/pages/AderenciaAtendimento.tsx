import KPICard from "@/components/dashboard/KPICard";
import SectionCard from "@/components/dashboard/SectionCard";
import { aderenciaKPIs, filialPerformance } from "@/data/mockData";
import { ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Tooltip } from "recharts";

const radarData = [
  { dim: "Pedidos", valor: 91.2 },
  { dim: "Volumes", valor: 88.7 },
  { dim: "Peso", valor: 93.1 },
  { dim: "KM", valor: 86.4 },
  { dim: "Tempo", valor: 84.9 },
  { dim: "Match", valor: 76.3 },
];

export default function AderenciaAtendimento() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {aderenciaKPIs.map((kpi, i) => (
          <KPICard key={kpi.label} data={kpi} delay={i * 60} />
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <SectionCard title="Radar de Aderência" subtitle="Visão consolidada de todas as dimensões" delay={400}>
          <div className="h-64 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData} outerRadius="75%">
                <PolarGrid stroke="hsl(220 13% 91%)" />
                <PolarAngleAxis dataKey="dim" tick={{ fontSize: 11, fontWeight: 700, fill: "#667085" }} />
                <PolarRadiusAxis domain={[0, 100]} tick={{ fontSize: 10, fill: "#98A2B3" }} />
                <Tooltip contentStyle={{ borderRadius: 10, border: "none", boxShadow: "0 8px 24px rgba(0,0,0,0.08)", fontSize: 12, fontWeight: 600 }} />
                <Radar dataKey="valor" stroke="#522B8F" fill="#522B8F" fillOpacity={0.18} strokeWidth={2} name="Aderência %" />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>

        <SectionCard title="Entregas Efetivas por Filial" subtitle="% entregas efetivas" delay={460}>
          <div className="space-y-2">
            {filialPerformance.map(f => (
              <div key={f.filial} className="flex items-center gap-3">
                <span className="text-[13px] font-semibold w-24 shrink-0">{f.filial}</span>
                <div className="flex-1 h-5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${f.entregasEfetivas}%`,
                      background: f.entregasEfetivas >= 95 ? "hsl(152 60% 40%)" : f.entregasEfetivas >= 93 ? "hsl(38 92% 50%)" : "hsl(0 72% 51%)",
                    }}
                  />
                </div>
                <span className="text-[13px] font-bold tabular-nums w-14 text-right">{f.entregasEfetivas}%</span>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
