import KPICard from "@/components/dashboard/KPICard";
import SectionCard from "@/components/dashboard/SectionCard";
import { frotaKPIs } from "@/data/mockData";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";

const ocupacaoPorTipo = [
  { tipo: "VUC", pedidos: 86.2, volumes: 74.1, composta: 80.2 },
  { tipo: "3/4", pedidos: 82.4, volumes: 70.8, composta: 76.6 },
  { tipo: "Toco", pedidos: 88.1, volumes: 78.3, composta: 83.2 },
  { tipo: "Truck", pedidos: 79.6, volumes: 68.4, composta: 74.0 },
  { tipo: "Carreta", pedidos: 91.3, volumes: 82.7, composta: 87.0 },
];

export default function FrotaCapacidade() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {frotaKPIs.map((kpi, i) => (
          <KPICard key={kpi.label} data={kpi} delay={i * 60} />
        ))}
      </div>

      <SectionCard title="Ocupação por Tipo de Veículo" subtitle="Pedidos, volumes e composta (%)" delay={350}>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={ocupacaoPorTipo}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 13% 91%)" />
              <XAxis dataKey="tipo" tick={{ fontSize: 11, fontWeight: 600, fill: "#667085" }} />
              <YAxis tick={{ fontSize: 11, fontWeight: 600, fill: "#667085" }} domain={[0, 100]} />
              <Tooltip contentStyle={{ borderRadius: 10, border: "none", boxShadow: "0 8px 24px rgba(0,0,0,0.08)", fontSize: 12, fontWeight: 600 }} />
              <Legend wrapperStyle={{ fontSize: 11, fontWeight: 700 }} />
              <Bar dataKey="pedidos" fill="#522B8F" name="Pedidos %" radius={[4, 4, 0, 0]} barSize={18} />
              <Bar dataKey="volumes" fill="#EC5B13" name="Volumes %" radius={[4, 4, 0, 0]} barSize={18} />
              <Bar dataKey="composta" fill="#667085" name="Composta %" radius={[4, 4, 0, 0]} barSize={18} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </SectionCard>
    </div>
  );
}
