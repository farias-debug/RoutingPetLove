import KPICard from "@/components/dashboard/KPICard";
import SectionCard from "@/components/dashboard/SectionCard";
import StatusChip from "@/components/dashboard/StatusChip";
import {
  resumoKPIs, weeklyTrend, filialPerformance, alerts,
  alertTypeLabels, alertTypeColors
} from "@/data/mockData";
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis,
  CartesianGrid, Tooltip, BarChart, Bar
} from "recharts";

export default function ResumoExecutivo() {
  return (
    <div className="space-y-6">
      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {resumoKPIs.map((kpi, i) => (
          <KPICard key={kpi.label} data={kpi} delay={i * 60} />
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Weekly trend */}
        <SectionCard title="Tendência Semanal" subtitle="Rotas e Entregas Efetivas por semana" delay={400}>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={weeklyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 13% 91%)" />
                <XAxis dataKey="semana" tick={{ fontSize: 11, fontWeight: 600, fill: "#667085" }} />
                <YAxis tick={{ fontSize: 11, fontWeight: 600, fill: "#667085" }} />
                <Tooltip
                  contentStyle={{ borderRadius: 10, border: "none", boxShadow: "0 8px 24px rgba(0,0,0,0.08)", fontSize: 12, fontWeight: 600 }}
                />
                <Area type="monotone" dataKey="rotas" stroke="#522B8F" fill="#522B8F" fillOpacity={0.12} strokeWidth={2} name="Rotas" />
                <Area type="monotone" dataKey="pedidos" stroke="#EC5B13" fill="#EC5B13" fillOpacity={0.08} strokeWidth={2} name="Pedidos" yAxisId={0} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>

        {/* Filial performance */}
        <SectionCard title="Performance por Filial" subtitle="Score operacional e entregas efetivas" delay={460}>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={filialPerformance} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 13% 91%)" />
                <XAxis type="number" tick={{ fontSize: 11, fontWeight: 600, fill: "#667085" }} domain={[0, 100]} />
                <YAxis dataKey="filial" type="category" width={80} tick={{ fontSize: 11, fontWeight: 600, fill: "#667085" }} />
                <Tooltip
                  contentStyle={{ borderRadius: 10, border: "none", boxShadow: "0 8px 24px rgba(0,0,0,0.08)", fontSize: 12, fontWeight: 600 }}
                />
                <Bar dataKey="score" fill="#522B8F" radius={[0, 4, 4, 0]} name="Score" barSize={14} />
                <Bar dataKey="entregasEfetivas" fill="#EC5B13" radius={[0, 4, 4, 0]} name="Entregas %" barSize={14} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>
      </div>

      {/* Alerts table */}
      <SectionCard title="Alertas Operacionais" subtitle="Últimas ocorrências por rota" delay={520}>
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-2 px-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Rota</th>
                <th className="text-left py-2 px-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Filial</th>
                <th className="text-left py-2 px-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Tipo</th>
                <th className="text-left py-2 px-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Transportador</th>
                <th className="text-left py-2 px-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Descrição</th>
              </tr>
            </thead>
            <tbody>
              {alerts.map(a => (
                <tr key={a.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <td className="py-2.5 px-3 font-bold">{a.rota}</td>
                  <td className="py-2.5 px-3 font-semibold text-muted-foreground">{a.filial}</td>
                  <td className="py-2.5 px-3">
                    <StatusChip label={alertTypeLabels[a.tipo]} colorClass={alertTypeColors[a.tipo]} />
                  </td>
                  <td className="py-2.5 px-3 font-semibold">{a.transportador}</td>
                  <td className="py-2.5 px-3 text-muted-foreground">{a.descricao}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  );
}
