import SectionCard from "@/components/dashboard/SectionCard";
import StatusChip from "@/components/dashboard/StatusChip";
import { transportadorData } from "@/data/mockData";
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from "recharts";

const COLORS = ["#522B8F", "#6B3FB3", "#EC5B13", "#F5913D", "#667085", "#98A2B3", "#D0D5DD"];

export default function Transportadores() {
  return (
    <div className="space-y-6">
      <div className="grid lg:grid-cols-2 gap-6">
        <SectionCard title="Share dos Transportadores" subtitle="Participação % nas rotas" delay={100}>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={transportadorData}
                  dataKey="share"
                  nameKey="transportador"
                  cx="50%"
                  cy="50%"
                  outerRadius={90}
                  innerRadius={50}
                  strokeWidth={2}
                  stroke="hsl(0 0% 100%)"
                  label={({ transportador, share }) => `${transportador} ${share}%`}
                  labelLine={{ stroke: "#98A2B3", strokeWidth: 1 }}
                >
                  {transportadorData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: 10, border: "none", boxShadow: "0 8px 24px rgba(0,0,0,0.08)", fontSize: 12, fontWeight: 600 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>

        <SectionCard title="Ranking de Transportadores" subtitle="Por score operacional" delay={160}>
          <div className="overflow-x-auto">
            <table className="w-full text-[13px]">
              <thead>
                <tr className="border-b border-border">
                  {["Transportador", "Rotas", "Share", "Entregas %", "Score"].map(h => (
                    <th key={h} className="text-left py-2 px-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[...transportadorData].sort((a, b) => b.score - a.score).map(t => (
                  <tr key={t.transportador} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                    <td className="py-2.5 px-3 font-bold">{t.transportador}</td>
                    <td className="py-2.5 px-3 tabular-nums">{t.rotas}</td>
                    <td className="py-2.5 px-3 tabular-nums">{t.share}%</td>
                    <td className="py-2.5 px-3">
                      <StatusChip
                        label={`${t.entregasEfetivas}%`}
                        colorClass={t.entregasEfetivas >= 95 ? "bg-success/15 text-success" : t.entregasEfetivas >= 93 ? "bg-warning/15 text-warning" : "bg-destructive/15 text-destructive"}
                      />
                    </td>
                    <td className="py-2.5 px-3 font-bold tabular-nums">{t.score}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
