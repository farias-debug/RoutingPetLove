import KPICard from "@/components/dashboard/KPICard";
import SectionCard from "@/components/dashboard/SectionCard";
import { planejadoVsRealizado } from "@/data/mockData";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";

export default function PlanejadoRealizado() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Aderência Pedidos", value: 91.2, unit: "%", trend: "up" as const, trendValue: "+0.4pp", status: "success" as const },
          { label: "Aderência Volumes", value: 88.7, unit: "%", trend: "down" as const, trendValue: "-0.8pp", status: "warning" as const },
          { label: "Aderência Peso", value: 93.1, unit: "%", trend: "up" as const, trendValue: "+1.2pp", status: "success" as const },
          { label: "Aderência KM", value: 86.4, unit: "%", trend: "neutral" as const, trendValue: "=", status: "neutral" as const },
        ].map((kpi, i) => (
          <KPICard key={kpi.label} data={kpi} delay={i * 60} />
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <SectionCard title="Planejado × Realizado — Pedidos" subtitle="Por filial" delay={300}>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={planejadoVsRealizado}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 13% 91%)" />
                <XAxis dataKey="filial" tick={{ fontSize: 11, fontWeight: 600, fill: "#667085" }} />
                <YAxis tick={{ fontSize: 11, fontWeight: 600, fill: "#667085" }} />
                <Tooltip contentStyle={{ borderRadius: 10, border: "none", boxShadow: "0 8px 24px rgba(0,0,0,0.08)", fontSize: 12, fontWeight: 600 }} />
                <Legend wrapperStyle={{ fontSize: 11, fontWeight: 700 }} />
                <Bar dataKey="planejadoPedidos" fill="#522B8F" fillOpacity={0.3} name="Planejado" radius={[4, 4, 0, 0]} />
                <Bar dataKey="realizadoPedidos" fill="#522B8F" name="Realizado" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>

        <SectionCard title="Planejado × Realizado — Volumes" subtitle="Por filial" delay={360}>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={planejadoVsRealizado}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 13% 91%)" />
                <XAxis dataKey="filial" tick={{ fontSize: 11, fontWeight: 600, fill: "#667085" }} />
                <YAxis tick={{ fontSize: 11, fontWeight: 600, fill: "#667085" }} />
                <Tooltip contentStyle={{ borderRadius: 10, border: "none", boxShadow: "0 8px 24px rgba(0,0,0,0.08)", fontSize: 12, fontWeight: 600 }} />
                <Legend wrapperStyle={{ fontSize: 11, fontWeight: 700 }} />
                <Bar dataKey="planejadoVolumes" fill="#EC5B13" fillOpacity={0.3} name="Planejado" radius={[4, 4, 0, 0]} />
                <Bar dataKey="realizadoVolumes" fill="#EC5B13" name="Realizado" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
