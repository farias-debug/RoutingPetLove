import KPICard from "@/components/dashboard/KPICard";
import SectionCard from "@/components/dashboard/SectionCard";
import { tempoKPIs, weeklyTrend } from "@/data/mockData";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine } from "recharts";

export default function TempoSla() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {tempoKPIs.map((kpi, i) => (
          <KPICard key={kpi.label} data={kpi} delay={i * 60} />
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <SectionCard title="Entregas Efetivas por Semana" subtitle="% entregas efetivas vs meta (95%)" delay={350}>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={weeklyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 13% 91%)" />
                <XAxis dataKey="semana" tick={{ fontSize: 11, fontWeight: 600, fill: "#667085" }} />
                <YAxis tick={{ fontSize: 11, fontWeight: 600, fill: "#667085" }} domain={[90, 100]} />
                <Tooltip contentStyle={{ borderRadius: 10, border: "none", boxShadow: "0 8px 24px rgba(0,0,0,0.08)", fontSize: 12, fontWeight: 600 }} />
                <ReferenceLine y={95} stroke="#EC5B13" strokeDasharray="6 3" label={{ value: "Meta 95%", fontSize: 10, fill: "#EC5B13", fontWeight: 700 }} />
                <Line type="monotone" dataKey="entregasEfetivas" stroke="#522B8F" strokeWidth={2.5} dot={{ r: 4, fill: "#522B8F" }} name="Entregas %" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>

        <SectionCard title="SPR Pedidos por Semana" subtitle="Pedidos/rota vs meta (15)" delay={410}>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={weeklyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 13% 91%)" />
                <XAxis dataKey="semana" tick={{ fontSize: 11, fontWeight: 600, fill: "#667085" }} />
                <YAxis tick={{ fontSize: 11, fontWeight: 600, fill: "#667085" }} domain={[13, 17]} />
                <Tooltip contentStyle={{ borderRadius: 10, border: "none", boxShadow: "0 8px 24px rgba(0,0,0,0.08)", fontSize: 12, fontWeight: 600 }} />
                <ReferenceLine y={15} stroke="#EC5B13" strokeDasharray="6 3" label={{ value: "Meta 15", fontSize: 10, fill: "#EC5B13", fontWeight: 700 }} />
                <Line type="monotone" dataKey="sprPedidos" stroke="#522B8F" strokeWidth={2.5} dot={{ r: 4, fill: "#522B8F" }} name="SPR Ped." />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
