import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import DashboardLayout from "@/components/dashboard/DashboardLayout";
import ResumoExecutivo from "@/pages/ResumoExecutivo";
import PlanejadoRealizado from "@/pages/PlanejadoRealizado";
import CustosEficiencia from "@/pages/CustosEficiencia";
import FrotaCapacidade from "@/pages/FrotaCapacidade";
import TempoSla from "@/pages/TempoSla";
import AderenciaAtendimento from "@/pages/AderenciaAtendimento";
import Transportadores from "@/pages/Transportadores";
import MotoristasJornada from "@/pages/MotoristasJornada";
import InvestigacaoOperacional from "@/pages/InvestigacaoOperacional";
import NotFound from "@/pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<DashboardLayout><ResumoExecutivo /></DashboardLayout>} />
          <Route path="/planejado-realizado" element={<DashboardLayout><PlanejadoRealizado /></DashboardLayout>} />
          <Route path="/custos" element={<DashboardLayout><CustosEficiencia /></DashboardLayout>} />
          <Route path="/frota" element={<DashboardLayout><FrotaCapacidade /></DashboardLayout>} />
          <Route path="/tempo-sla" element={<DashboardLayout><TempoSla /></DashboardLayout>} />
          <Route path="/aderencia" element={<DashboardLayout><AderenciaAtendimento /></DashboardLayout>} />
          <Route path="/transportadores" element={<DashboardLayout><Transportadores /></DashboardLayout>} />
          <Route path="/motoristas" element={<DashboardLayout><MotoristasJornada /></DashboardLayout>} />
          <Route path="/alertas" element={<DashboardLayout><InvestigacaoOperacional /></DashboardLayout>} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
